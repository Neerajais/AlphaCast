// Comprehensive utility functions for stock data handling

import stocksDb from "@/data/custom-indian-stocks.json"
import { getReferencePrice } from "@/utils/reference-prices"

const U = (s: string) => s.toUpperCase()

// Build sets/maps from the JSON database
type DbEntry = { symbol: string; name: string; exchange: string }
const DB_ENTRIES: DbEntry[] = (stocksDb as DbEntry[]).map((e) => ({
  symbol: U(e.symbol),
  name: e.name,
  exchange: e.exchange.toUpperCase(),
}))

const DB_SYMBOL_SET = new Set(DB_ENTRIES.map((e) => e.symbol))
const DB_META = new Map<string, DbEntry>(DB_ENTRIES.map((e) => [e.symbol, e]))

// Legacy static list for older paths (kept for compatibility)
export const INDIAN_STOCK_SYMBOLS: string[] = Array.from(DB_SYMBOL_SET)

// Determine Indian by explicit exchange or presence in DB
export const isIndianStock = (symbol: string, exchangeHint?: string): boolean => {
  if (exchangeHint) {
    const e = exchangeHint.toUpperCase()
    if (e.includes("NSE") || e.includes("BSE")) return true
  }
  return DB_SYMBOL_SET.has(U(symbol))
}

// Alpha Vantage mapping; if Indian -> add .NS
export const toAlphaVantageSymbol = (symbol: string, exchangeHint?: string): string => {
  const s = U(symbol)
  return isIndianStock(s, exchangeHint) ? `${s}.NS` : s
}

// Simple range heuristic (used only when no anchor exists)
export const getIndianStockPriceRange = (symbol: string): [number, number] => {
  // If we have a reference, make a tight range around it
  const ref = getReferencePrice(symbol)
  if (ref) {
    return [ref * 0.92, ref * 1.08]
  }
  // Otherwise a generic range
  return [100, 1200]
}

// Company name lookup from DB, fallback to "SYMBOL Ltd."
export const getCompanyName = (symbol: string): string => {
  const s = U(symbol)
  const hit = DB_META.get(s)
  if (hit) return hit.name
  return `${s} Ltd.`
}

// Minimal sector mapping; use generic if unknown
export const getSector = (symbol: string): string => {
  // If you want richer sectors, extend DB to include sector and look it up here.
  // Using simple buckets for now.
  return "Diversified"
}

export const getIndustry = (symbol: string): string => {
  return "General"
}

// Pricing helper: always ₹ for Indian, $ for US, anchored tightly if reference exists
export const getStockPricing = (symbol: string) => {
  const s = U(symbol)
  const indian = isIndianStock(s)
  const ref = getReferencePrice(s)

  if (ref && ref > 0) {
    const noise = indian ? 0.01 : 0.008 // ±1% INR, ±0.8% USD
    const price = ref * (1 + (Math.random() - 0.5) * 2 * noise)
    return {
      currency: indian ? "₹" : "$",
      price,
      isIndian: indian,
      marketCap: indian
        ? `₹${(Math.random() * 500000 + 10000).toFixed(0)} Cr`
        : `$${(Math.random() * 2000 + 100).toFixed(0)}B`,
      volume: Math.floor(Math.random() * (indian ? 50_000_000 : 100_000_000)),
      exchange: indian ? "NSE" : "NASDAQ",
    }
  }

  if (indian) {
    const [lo, hi] = getIndianStockPriceRange(s)
    const price = lo + Math.random() * (hi - lo)
    return {
      currency: "₹",
      price,
      isIndian: true,
      marketCap: `₹${(Math.random() * 500000 + 10000).toFixed(0)} Cr`,
      volume: Math.floor(Math.random() * 50_000_000),
      exchange: "NSE",
    }
  } else {
    const price = 50 + Math.random() * 400
    return {
      currency: "$",
      price,
      isIndian: false,
      marketCap: `$${(Math.random() * 2000 + 100).toFixed(0)}B`,
      volume: Math.floor(Math.random() * 100_000_000),
      exchange: "NASDAQ",
    }
  }
}

export const getStockDescription = (symbol: string): string => {
  const s = U(symbol)
  const name = getCompanyName(s)
  return `${name} is a leading company in the ${getSector(s)} sector, specializing in ${getIndustry(s)}.`
}
