// Reference price anchors to keep generated/fallback prices close to reality.
// These are anchored to approximate current market prices for accuracy.

const U = (s: string) => s.toUpperCase()

// INR anchors - Top 100 Indian stocks with accurate reference prices
const INR: Record<string, number> = {
  // Top Tier Blue Chips
  RELIANCE: 1280,
  TCS: 3850,
  HDFCBANK: 1680,
  ICICIBANK: 1220,
  BHARTIARTL: 1050,
  INFY: 1800,
  LIC: 890,
  SBIN: 750,
  ITC: 520,
  HINDUNILVR: 2150,
  
  // Large Cap Index Stocks
  LT: 3950,
  KOTAKBANK: 2150,
  BAJFINANCE: 8200,
  HCLTECH: 1680,
  MARUTI: 11800,
  AXISBANK: 1410,
  NTPC: 280,
  ASIANPAINT: 3680,
  POWERGRID: 320,
  TITAN: 3320,
  
  // Cement & Materials
  ULTRATECH: 11200,
  SHREECEM: 31500,
  AMBUJACEM: 580,
  
  // Pharma & Healthcare
  SUNPHARMA: 1420,
  CIPLA: 1580,
  DRREDDY: 6850,
  APOLLOHOSP: 6500,
  BIOCON: 450,
  
  // FMCG & Consumer
  NESTLEIND: 27500,
  BRITANNIA: 6100,
  DABUR: 680,
  BERGEPAINT: 920,
  GODREJCP: 1350,
  COLPAL: 2450,
  
  // IT & Tech
  WIPRO: 630,
  TECHM: 1580,
  LTIM: 6200,
  MPHASIS: 2950,
  
  // Metals & Mining
  JSWSTEEL: 1050,
  TATASTEEL: 180,
  HINDALCO: 650,
  JINDALSTEL: 950,
  NMDC: 170,
  
  // Energy & Power
  ONGC: 250,
  GAIL: 165,
  TATAPOWER: 520,
  RECLTD: 270,
  PFC: 380,
  ADANIPOWER: 620,
  
  // Automobiles
  TATAMOTORS: 1280,
  HEROMOTOCO: 3850,
  EICHERMOT: 4650,
  TVSMOTOR: 2650,
  BAJAJAUTO: 6500,
  
  // Banks & Financial Services
  SBILIFE: 1820,
  HDFCLIFE: 820,
  ICICIPRULI: 720,
  INDUSINDBK: 1880,
  MUTHOOTFIN: 1520,
  MANAPPURAM: 220,
  
  // Adani Group
  ADANIENT: 3250,
  ADANIPORTS: 1680,
  ADANIGREEN: 1380,
  ADANITRANS: 380,
  
  // Tata Group
  TATACONSUM: 1350,
  TATACHEM: 1450,
  TATAELXSI: 8950,
  
  // Infrastructure & Real Estate
  DLF: 850,
  LODHA: 2150,
  
  // Insurance & Services
  SBICARD: 620,
  IRCTC: 850,
  
  // Logistics & Transport
  INDIGO: 3850,
  
  // Retail & E-commerce
  ZOMATO: 165,
  DMART: 5200,
  NAUKRI: 6100,
  TRENT: 2800,
  
  // Aditya Birla Group
  ABCAPITAL: 280,
  ABFRL: 420,
  ABSLAMC: 720,
  BIRLAMONEY: 105,
  
  // Others
  PIDILITIND: 3250,
  PAGEIND: 56500,
  JUBLFOOD: 750,
  GRASIM: 2450,
  PIRAMAL: 950,
  SIEMENS: 5850,
  ABB: 6950,
  SRF: 2550,
  BEL: 285,
  HAL: 3350,
  BHEL: 220,
  UPL: 820,
  UNITEDSPIRIT: 1150,
  UNITEDBREWERIES: 1650,
  IDEA: 18,
  HPCL: 480,
  BPCL: 520,
  TORNTPHARMA: 2950,
  GLENBIOTECH: 1580,
  CANBANK: 420,
  BANKBARODA: 320,
  PNB: 105,
  COALINDIA: 385,
  LTTS: 5300,
  COFORGE: 6800,
  PERSISTENT: 7150,
  NYKAA: 230,
  PAYTM: 620,
  POLICYBZR: 980,
  
  // Premium Stock - MRF
  MRF: 129500,
}

// USD anchors (subset for US stocks)
const USD: Record<string, number> = {
  AAPL: 230,
  MSFT: 460,
  GOOGL: 195,
  AMZN: 195,
  NVDA: 145,
  TSLA: 285,
}

// Named export required by other modules
export function getReferencePrice(symbol: string): number | undefined {
  const s = U(symbol)
  return INR[s] ?? USD[s]
}

export const REFERENCE_ANCHORS = { INR, USD }
