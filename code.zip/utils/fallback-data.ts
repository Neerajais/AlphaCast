// Utilities to generate realistic fallback series near a reference/anchor price.

import { getReferencePrice } from "@/utils/reference-prices"
import { isIndianStock } from "@/utils/stock-utils"

export type FallbackPoint = {
  date: string
  open: number
  high: number
  low: number
  close: number
  volume: number
}

/**
 * Generate a descending (newest-first) series of OHLC around an anchor/ref price.
 * Keeps drift and volatility modest so it's "close to real".
 */
export function generateFallbackSeries(symbol: string, days = 180): FallbackPoint[] {
  const ref = getReferencePrice(symbol) ?? (isIndianStock(symbol) ? 500 : 100)
  // Daily drift and volatility tuned for equities
  const dailyDrift = 0.0005 // ~0.05% per day drift
  const dailyVol = 0.0125 // ~1.25% daily volatility

  const today = new Date()
  let price = ref

  const points: FallbackPoint[] = []
  for (let i = 0; i < days; i++) {
    const d = new Date(today)
    d.setDate(today.getDate() - i)
    // random walk with drift
    const ret = dailyDrift + (Math.random() - 0.5) * 2 * dailyVol
    const next = Math.max(0.01, price * (1 + ret))

    // Build OHLC around next
    const spread = next * 0.006 + Math.random() * (next * 0.004) // ~0.6-1% intraday range
    const open = clamp(next + (Math.random() - 0.5) * spread, next * 0.97, next * 1.03)
    const close = next
    const high = Math.max(open, close) + Math.random() * (spread * 0.5)
    const low = Math.min(open, close) - Math.random() * (spread * 0.5)

    const volumeBase = isIndianStock(symbol) ? 10_000_00 : 50_000_0 // scale
    const volume = Math.floor(volumeBase * (1 + Math.random() * 10))

    points.push({
      date: d.toISOString().split("T")[0],
      open,
      high: Math.max(high, open, close),
      low: Math.max(0, Math.min(low, open, close)),
      close,
      volume,
    })

    price = next
  }

  // Return newest-first
  return points
}

function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v))
}
