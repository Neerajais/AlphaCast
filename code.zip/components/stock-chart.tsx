"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import type { StockData } from "@/types/stock"

interface StockChartProps {
  data: StockData
}

export default function StockChart({ data }: StockChartProps) {
  const chartData = data.timeSeries
    .map((item) => ({
      date: new Date(item.date).toLocaleDateString(),
      close: item.close,
      ma20: item.ma20,
      ma50: item.ma50,
      volume: item.volume,
    }))
    .reverse()

  return (
    <div className="w-full h-96">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" tick={{ fontSize: 12 }} interval="preserveStartEnd" />
          <YAxis tick={{ fontSize: 12 }} />
          <Tooltip
            formatter={(value: number, name: string) => [
              `${data.currency || (data.isIndian ? "₹" : "$")}${value.toFixed(2)}`,
              name === "close" ? "Close Price" : name === "ma20" ? "20-Day MA" : "50-Day MA",
            ]}
          />
          <Legend />
          <Line type="monotone" dataKey="close" stroke="#2563eb" strokeWidth={2} name="Close Price" dot={false} />
          <Line
            type="monotone"
            dataKey="ma20"
            stroke="#dc2626"
            strokeWidth={1}
            strokeDasharray="5 5"
            name="20-Day MA"
            dot={false}
          />
          <Line
            type="monotone"
            dataKey="ma50"
            stroke="#16a34a"
            strokeWidth={1}
            strokeDasharray="5 5"
            name="50-Day MA"
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
