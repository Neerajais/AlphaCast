"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Building, Users, Globe, Calendar } from "lucide-react"

interface CompanyInfoProps {
  stockData: any
}

export default function CompanyInfo({ stockData }: CompanyInfoProps) {
  const financialMetrics = [
    { label: "Market Cap", value: stockData.marketCap },
    { label: "P/E Ratio", value: stockData.pe },
    { label: "EPS", value: `$${stockData.eps}` },
    { label: "Dividend Yield", value: `${stockData.dividend}%` },
    { label: "52W High", value: `$${(stockData.price * 1.2).toFixed(2)}` },
    { label: "52W Low", value: `$${(stockData.price * 0.8).toFixed(2)}` },
    { label: "Beta", value: (0.8 + Math.random() * 0.8).toFixed(2) },
    { label: "ROE", value: `${(10 + Math.random() * 20).toFixed(1)}%` },
  ]

  return (
    <div className="space-y-6">
      {/* Company Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Building className="h-5 w-5 mr-2" />
            Company Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-lg mb-2">{stockData.name}</h3>
              <p className="text-gray-600 mb-4">{stockData.description}</p>

              <div className="space-y-2">
                <div className="flex items-center">
                  <Badge variant="secondary" className="mr-2">
                    {stockData.sector}
                  </Badge>
                  <span className="text-sm text-gray-600">Sector</span>
                </div>
                <div className="flex items-center">
                  <Badge variant="outline" className="mr-2">
                    {stockData.industry}
                  </Badge>
                  <span className="text-sm text-gray-600">Industry</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center">
                <Users className="h-5 w-5 mr-2 text-gray-500" />
                <div>
                  <div className="font-medium">Employees</div>
                  <div className="text-sm text-gray-600">
                    {(50000 + Math.floor(Math.random() * 200000)).toLocaleString()}
                  </div>
                </div>
              </div>

              <div className="flex items-center">
                <Globe className="h-5 w-5 mr-2 text-gray-500" />
                <div>
                  <div className="font-medium">Headquarters</div>
                  <div className="text-sm text-gray-600">Cupertino, CA</div>
                </div>
              </div>

              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-gray-500" />
                <div>
                  <div className="font-medium">Founded</div>
                  <div className="text-sm text-gray-600">{1970 + Math.floor(Math.random() * 30)}</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Financial Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Key Financial Metrics</CardTitle>
          <CardDescription>Important financial ratios and metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {financialMetrics.map((metric, index) => (
              <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">{metric.label}</div>
                <div className="text-lg font-bold">{metric.value}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Summary</CardTitle>
          <CardDescription>Recent stock performance metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">+12.5%</div>
              <div className="text-sm text-gray-600">1 Month Return</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">+28.3%</div>
              <div className="text-sm text-gray-600">3 Month Return</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">+45.7%</div>
              <div className="text-sm text-gray-600">1 Year Return</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
