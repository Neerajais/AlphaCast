"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, ExternalLink, TrendingUp, AlertCircle } from "lucide-react"

interface NewsItem {
  id: string
  title: string
  summary: string
  source: string
  publishedAt: string
  category: "market" | "earnings" | "analysis" | "breaking"
  sentiment: "positive" | "negative" | "neutral"
  relatedStocks: string[]
  url: string
}

export default function NewsSection() {
  const [news, setNews] = useState<NewsItem[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("all")

  useEffect(() => {
    const mockNews: NewsItem[] = [
      {
        id: "1",
        title: "Apple Reports Strong Q4 Earnings, iPhone Sales Exceed Expectations",
        summary:
          "Apple Inc. reported quarterly earnings that beat analyst expectations, driven by strong iPhone 15 sales and services revenue growth.",
        source: "MarketWatch",
        publishedAt: "2024-01-15T10:30:00Z",
        category: "earnings",
        sentiment: "positive",
        relatedStocks: ["AAPL"],
        url: "#",
      },
      {
        id: "2",
        title: "Tesla Stock Surges on Autonomous Driving Breakthrough",
        summary:
          "Tesla shares jumped 8% in pre-market trading following news of a major breakthrough in their Full Self-Driving technology.",
        source: "Reuters",
        publishedAt: "2024-01-15T09:15:00Z",
        category: "breaking",
        sentiment: "positive",
        relatedStocks: ["TSLA"],
        url: "#",
      },
      {
        id: "3",
        title: "Federal Reserve Signals Potential Rate Cuts in 2024",
        summary:
          "Fed officials hint at possible interest rate reductions later this year, boosting market sentiment across tech stocks.",
        source: "Bloomberg",
        publishedAt: "2024-01-15T08:45:00Z",
        category: "market",
        sentiment: "positive",
        relatedStocks: ["SPY", "QQQ"],
        url: "#",
      },
      {
        id: "4",
        title: "NVIDIA Faces Supply Chain Challenges for AI Chips",
        summary:
          "The semiconductor giant reports potential delays in AI chip production due to ongoing supply chain constraints.",
        source: "TechCrunch",
        publishedAt: "2024-01-15T07:20:00Z",
        category: "analysis",
        sentiment: "negative",
        relatedStocks: ["NVDA"],
        url: "#",
      },
      {
        id: "5",
        title: "Microsoft Azure Revenue Growth Accelerates",
        summary: "Microsoft's cloud computing division shows strong momentum with 30% year-over-year growth in Q4.",
        source: "CNBC",
        publishedAt: "2024-01-15T06:30:00Z",
        category: "earnings",
        sentiment: "positive",
        relatedStocks: ["MSFT"],
        url: "#",
      },
      {
        id: "6",
        title: "Amazon Prime Day Sales Hit Record High",
        summary: "Amazon reports its biggest Prime Day event ever, with sales exceeding $12 billion globally.",
        source: "Wall Street Journal",
        publishedAt: "2024-01-15T05:45:00Z",
        category: "market",
        sentiment: "positive",
        relatedStocks: ["AMZN"],
        url: "#",
      },
    ]

    setNews(mockNews)
  }, [])

  const categories = [
    { id: "all", label: "All News" },
    { id: "breaking", label: "Breaking" },
    { id: "market", label: "Market" },
    { id: "earnings", label: "Earnings" },
    { id: "analysis", label: "Analysis" },
  ]

  const filteredNews = selectedCategory === "all" ? news : news.filter((item) => item.category === selectedCategory)

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return "text-green-600 bg-green-50"
      case "negative":
        return "text-red-600 bg-red-50"
      default:
        return "text-gray-600 bg-gray-50"
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "breaking":
        return "bg-red-500"
      case "earnings":
        return "bg-blue-500"
      case "market":
        return "bg-green-500"
      case "analysis":
        return "bg-purple-500"
      default:
        return "bg-gray-500"
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const now = new Date()
    const publishedAt = new Date(dateString)
    const diffInHours = Math.floor((now.getTime() - publishedAt.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) return "Just now"
    if (diffInHours < 24) return `${diffInHours}h ago`
    return `${Math.floor(diffInHours / 24)}d ago`
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold">Market News</h3>
          <p className="text-gray-600">Latest financial news and market updates</p>
        </div>
        <Button variant="outline">
          <ExternalLink className="h-4 w-4 mr-2" />
          View All News
        </Button>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.id ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(category.id)}
          >
            {category.label}
          </Button>
        ))}
      </div>

      {/* News Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredNews.map((item) => (
          <Card key={item.id} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between mb-2">
                <Badge className={`${getCategoryColor(item.category)} text-white`}>
                  {item.category === "breaking" && <AlertCircle className="h-3 w-3 mr-1" />}
                  {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
                </Badge>
                <Badge variant="outline" className={getSentimentColor(item.sentiment)}>
                  {item.sentiment}
                </Badge>
              </div>
              <CardTitle className="text-lg leading-tight">{item.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-sm mb-4 line-clamp-3">{item.summary}</CardDescription>

              <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {formatTimeAgo(item.publishedAt)}
                </div>
                <span>{item.source}</span>
              </div>

              {item.relatedStocks.length > 0 && (
                <div className="flex items-center space-x-2 mb-3">
                  <span className="text-sm text-gray-500">Related:</span>
                  {item.relatedStocks.map((stock) => (
                    <Badge key={stock} variant="secondary" className="text-xs">
                      {stock}
                    </Badge>
                  ))}
                </div>
              )}

              <Button variant="ghost" size="sm" className="w-full">
                Read Full Article
                <ExternalLink className="h-3 w-3 ml-2" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Market Sentiment Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 mr-2" />
            Market Sentiment Analysis
          </CardTitle>
          <CardDescription>Overall market sentiment based on recent news</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">68%</div>
              <div className="text-sm text-gray-600">Positive News</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-600">20%</div>
              <div className="text-sm text-gray-600">Neutral News</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600">12%</div>
              <div className="text-sm text-gray-600">Negative News</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
