"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Star, Eye } from "lucide-react"
import Link from "next/link"
import { isIndianStock, getStockPricing, getCompanyName, getSector } from "@/utils/stock-utils"

interface PopularStock {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  volume: number
  marketCap: string
  sector: string
  prediction: "bullish" | "bearish" | "neutral"
  confidence: number
  currency: string
  isIndian: boolean
  exchange: string
}

export default function PopularStocks() {
  const [stocks, setStocks] = useState<PopularStock[]>([])

  useEffect(() => {
    // Define popular stock symbols
    const popularSymbols = [
      // US stocks
      "AAPL",
      "MSFT",
      "GOOGL",
      // Indian stocks
      "TCS",
      "RELIANCE",
      "HDFCBANK",
      "TATASTEEL",
      "INFY",
      "MARUTI",
    ]

    // Generate stock data for each symbol
    const popularStocks: PopularStock[] = popularSymbols.map((symbol) => {
      const pricing = getStockPricing(symbol) // This will return correct currency
      const isIndian = isIndianStock(symbol)
      const change = (Math.random() - 0.5) * (isIndian ? pricing.price * 0.03 : 10)
      const changePercent = (change / pricing.price) * 100

      return {
        symbol,
        name: getCompanyName(symbol),
        price: pricing.price,
        change,
        changePercent,
        volume: pricing.volume,
        marketCap: pricing.marketCap,
        sector: getSector(symbol),
        prediction: Math.random() > 0.6 ? "bullish" : Math.random() > 0.4 ? "neutral" : "bearish",
        confidence: Math.round(70 + Math.random() * 25),
        currency: pricing.currency, // Use the currency from pricing
        isIndian,
        exchange: pricing.exchange,
      }
    })

    setStocks(popularStocks)
  }, [])

  const getPredictionColor = (prediction: string) => {
    switch (prediction) {
      case "bullish":
        return "text-green-600 bg-green-50"
      case "bearish":
        return "text-red-600 bg-red-50"
      default:
        return "text-yellow-600 bg-yellow-50"
    }
  }

  const getPredictionIcon = (prediction: string) => {
    switch (prediction) {
      case "bullish":
        return <TrendingUp className="h-4 w-4" />
      case "bearish":
        return <TrendingDown className="h-4 w-4" />
      default:
        return <Eye className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold">Popular Stocks</h3>
          <p className="text-gray-600">Most watched stocks with AI predictions</p>
        </div>
        <Button variant="outline">
          <Star className="h-4 w-4 mr-2" />
          View All
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stocks.map((stock) => (
          <Card key={stock.symbol} className="hover:shadow-lg transition-all duration-200 cursor-pointer">
            <Link href={`/stock/${stock.symbol}`}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{stock.symbol}</CardTitle>
                    <CardDescription className="text-sm">{stock.name}</CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary">{stock.sector}</Badge>
                    <Badge variant="outline">{stock.exchange}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold">
                      {stock.currency}
                      {stock.price.toFixed(2)}
                    </div>
                    <div
                      className={`flex items-center text-sm ${stock.change >= 0 ? "text-green-600" : "text-red-600"}`}
                    >
                      {stock.change >= 0 ? (
                        <TrendingUp className="h-4 w-4 mr-1" />
                      ) : (
                        <TrendingDown className="h-4 w-4 mr-1" />
                      )}
                      {stock.change >= 0 ? "+" : ""}
                      {stock.currency}
                      {Math.abs(stock.change).toFixed(2)} ({Math.abs(stock.changePercent).toFixed(2)}%)
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-gray-500">Volume</div>
                      <div className="font-medium">{(stock.volume / 1000000).toFixed(1)}M</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Market Cap</div>
                      <div className="font-medium">{stock.marketCap}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t">
                    <div className="flex items-center space-x-2">
                      <Badge className={getPredictionColor(stock.prediction)}>
                        {getPredictionIcon(stock.prediction)}
                        <span className="ml-1 capitalize">{stock.prediction}</span>
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-500">{stock.confidence}% confidence</div>
                  </div>
                </div>
              </CardContent>
            </Link>
          </Card>
        ))}
      </div>
    </div>
  )
}
