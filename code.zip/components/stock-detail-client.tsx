"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Star, Download, Share2, TrendingUp, TrendingDown } from "lucide-react"
import StockChart from "@/components/stock-chart-detailed"
import TechnicalIndicators from "@/components/technical-indicators"
import PredictionPanel from "@/components/prediction-panel"
import CompanyInfo from "@/components/company-info"
import { getCompanyName, getIndustry, getSector, getStockPricing, isIndianStock } from "@/utils/stock-utils"

type InitialPayload = {
  stockData?: {
    symbol: string
    timeSeries: Array<{
      date: string
      open: number
      high: number
      low: number
      close: number
      volume: number
      ma20?: number
      ma50?: number
    }>
    lastRefreshed: string
    currency?: string
    isIndian?: boolean
    exchange?: string
  }
  predictions?: any
  source?: "live" | "fallback" | string
}

export default function StockDetailClient({
  symbol,
  exchange,
  initial,
}: {
  symbol: string
  exchange?: string
  initial: InitialPayload | null
}) {
  const synthesized = useMemo(() => {
    const pricing = getStockPricing(symbol)
    return {
      symbol,
      name: getCompanyName(symbol),
      price: pricing.price,
      change: (Math.random() - 0.5) * (pricing.isIndian ? 50 : 10),
      changePercent: (Math.random() - 0.5) * 5,
      volume: pricing.volume,
      marketCap: pricing.marketCap,
      pe: (15 + Math.random() * 20).toFixed(2),
      eps: pricing.isIndian ? `₹${(Math.random() * 100).toFixed(2)}` : `$${(Math.random() * 10).toFixed(2)}`,
      dividend: `${(Math.random() * 3).toFixed(2)}%`,
      sector: getSector(symbol),
      industry: getIndustry(symbol),
      description: `${getCompanyName(symbol)} is a leading company in the ${getSector(symbol)} sector, specializing in ${getIndustry(symbol)}.`,
      currency: pricing.currency,
      isIndian: pricing.isIndian,
      exchange: pricing.exchange,
      timeSeries: [] as any[],
    }
  }, [symbol])

  const [stockData, setStockData] = useState<any>(() => {
    if (initial?.stockData) {
      const s = initial.stockData
      const latest = s.timeSeries?.[0]
      return {
        symbol: s.symbol ?? symbol,
        name: getCompanyName(symbol),
        price: latest?.close ?? synthesized.price,
        change: 0,
        changePercent: 0,
        volume: latest?.volume ?? synthesized.volume,
        marketCap: synthesized.marketCap,
        pe: synthesized.pe,
        eps: synthesized.eps,
        dividend: synthesized.dividend,
        sector: getSector(symbol),
        industry: getIndustry(symbol),
        description: synthesized.description,
        currency: s.currency ?? (s.isIndian ? "₹" : "$"),
        isIndian: s.isIndian ?? isIndianStock(symbol, exchange),
        exchange: s.exchange ?? (isIndianStock(symbol, exchange) ? "NSE" : "US"),
        timeSeries: s.timeSeries ?? [],
      }
    }
    return synthesized
  })

  useEffect(() => {
    const ts = stockData.timeSeries
    if (Array.isArray(ts) && ts.length >= 2) {
      const latest = ts[0]
      const prev = ts[1]
      const change = latest.close - prev.close
      const pct = (change / (prev.close || latest.close)) * 100
      setStockData((prev: any) => ({
        ...prev,
        price: latest.close,
        change,
        changePercent: pct,
        volume: latest.volume ?? prev.volume ?? prev.volume,
      }))
    }
  }, [stockData.timeSeries])

  useEffect(() => {
    let cancelled = false
    const run = async () => {
      try {
        const res = await fetch("/api/stock-data", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ symbol, exchange }),
        })
        const json = await res.json()
        if (!cancelled && res.ok && json?.stockData?.timeSeries?.length) {
          const latest = json.stockData.timeSeries[0]
          setStockData((prev: any) => ({
            ...prev,
            ...json.stockData,
            price: latest?.close ?? prev?.price,
            volume: latest?.volume ?? prev?.volume,
          }))
        }
      } catch {
        // keep synthesized state
      }
    }
    run()
    const id = setInterval(run, 60_000)
    return () => {
      cancelled = true
      clearInterval(id)
    }
  }, [symbol, exchange])

  const source = initial?.source ?? "unknown"

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <header className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold">{stockData.symbol}</h1>
                <p className="text-gray-600">{stockData.name}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">{stockData.exchange}</Badge>
              <Button variant="outline" size="sm">
                <Star className="h-4 w-4 mr-2" />
                Watchlist
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </Button>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="md:col-span-2">
                <div className="text-4xl font-bold mb-2">
                  {stockData.currency}
                  {(stockData.price ?? 0).toFixed(2)}
                </div>
                <div
                  className={`flex items-center text-lg ${
                    (stockData.change ?? 0) >= 0 ? "text-green-600" : "text-red-600"
                  }`}
                >
                  {(stockData.change ?? 0) >= 0 ? (
                    <TrendingUp className="h-5 w-5 mr-2" />
                  ) : (
                    <TrendingDown className="h-5 w-5 mr-2" />
                  )}
                  {(stockData.change ?? 0) >= 0 ? "+" : ""}
                  {stockData.currency}
                  {Math.abs(stockData.change ?? 0).toFixed(2)} ({(stockData.changePercent ?? 0).toFixed(2)}%)
                </div>
                <div className="flex items-center space-x-4 mt-4">
                  <Badge variant="secondary">{stockData.sector}</Badge>
                  <Badge variant="outline">{stockData.industry}</Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-gray-500">Market Cap</div>
                  <div className="font-semibold">{stockData.marketCap}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Volume</div>
                  <div className="font-semibold">
                    {stockData.timeSeries?.[0]?.volume
                      ? (stockData.timeSeries[0].volume / 1_000_000).toFixed(1) + "M"
                      : (stockData.volume / 1_000_000).toFixed(1) + "M"}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">P/E Ratio</div>
                  <div className="font-semibold">{stockData.pe}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">EPS</div>
                  <div className="font-semibold">{stockData.eps}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="chart" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="chart">Chart & Analysis</TabsTrigger>
            <TabsTrigger value="predictions">AI Predictions</TabsTrigger>
            <TabsTrigger value="company">Company Info</TabsTrigger>
            <TabsTrigger value="news">News & Events</TabsTrigger>
          </TabsList>

          <TabsContent value="chart" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <StockChart
                  symbol={stockData.symbol}
                  currency={stockData.currency}
                  isIndian={stockData.isIndian}
                  timeSeries={stockData.timeSeries}
                />
              </div>
              <div>
                <TechnicalIndicators
                  symbol={stockData.symbol}
                  currency={stockData.currency}
                  isIndian={stockData.isIndian}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="predictions">
            <PredictionPanel
              symbol={stockData.symbol}
              currentPrice={stockData.price}
              currency={stockData.currency}
              isIndian={stockData.isIndian}
            />
          </TabsContent>

          <TabsContent value="company">
            <CompanyInfo stockData={stockData} />
          </TabsContent>

          <TabsContent value="news">
            <div className="text-center py-12">
              <p className="text-gray-600">News and events for {stockData.symbol} coming soon...</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="mb-2 text-sm text-gray-500">
          Source:{" "}
          <span className={initial?.source === "live" ? "text-emerald-600" : "text-amber-600"}>
            {initial?.source ?? "unknown"}
          </span>
        </div>
        <div className="text-gray-600 text-sm mb-4">
          Currency: {stockData.currency} • Exchange: {stockData.exchange} • Points: {stockData.timeSeries?.length ?? 0}
        </div>
      </div>
    </div>
  )
}
