"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Brain, Target, Zap, TrendingUp, TrendingDown } from "lucide-react"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts"

interface PredictionPanelProps {
  symbol: string
  currentPrice: number
  currency?: string
  isIndian?: boolean
}

interface Prediction {
  date: string
  price: number
  confidence: number
  model: string
}

export default function PredictionPanel({
  symbol,
  currentPrice,
  currency = "$",
  isIndian = false,
}: PredictionPanelProps) {
  const [selectedModel, setSelectedModel] = useState("lstm")
  const [predictions, setPredictions] = useState<Prediction[]>([])
  const [timeframe, setTimeframe] = useState("7d")

  const models = [
    { id: "lstm", name: "LSTM Neural Network", icon: Brain, accuracy: 87.5, color: "bg-blue-500" },
    { id: "prophet", name: "Prophet", icon: Target, accuracy: 82.3, color: "bg-green-500" },
    { id: "arima", name: "ARIMA", icon: Zap, accuracy: 79.8, color: "bg-purple-500" },
  ]

  useEffect(() => {
    const generatePredictions = () => {
      const days = timeframe === "7d" ? 7 : timeframe === "30d" ? 30 : 90

      // Create a realistic trend based on the model and stock
      let trendFactor = 0
      if (selectedModel === "lstm") {
        trendFactor = (Math.random() - 0.4) * 0.02 // LSTM slightly bullish bias
      } else if (selectedModel === "prophet") {
        trendFactor = (Math.random() - 0.5) * 0.025 // Prophet more volatile
      } else {
        trendFactor = (Math.random() - 0.5) * 0.015 // ARIMA more conservative
      }

      // Adjust trend based on stock type
      if (isIndian) {
        // Indian stocks might have different trend characteristics
        trendFactor *= 1.2
      }

      let currentPredictedPrice = currentPrice

      return Array.from({ length: days }, (_, i) => {
        const date = new Date()
        date.setDate(date.getDate() + i + 1)

        // Add daily volatility and trend
        const dailyVolatility = (Math.random() - 0.5) * 0.03 * currentPredictedPrice
        const dailyTrend = trendFactor * currentPredictedPrice

        // Update the price with trend and volatility
        currentPredictedPrice = currentPredictedPrice + dailyTrend + dailyVolatility

        // Ensure price doesn't go too low
        currentPredictedPrice = Math.max(currentPredictedPrice, currentPrice * 0.7)

        // Confidence decreases over time
        const confidence = Math.max(60, 95 - i * 1.2)

        return {
          date: date.toLocaleDateString(),
          price: currentPredictedPrice,
          confidence,
          model: selectedModel,
        }
      })
    }

    setPredictions(generatePredictions())
  }, [selectedModel, timeframe, currentPrice, isIndian])

  const selectedModelData = models.find((m) => m.id === selectedModel)
  const lastPrediction = predictions[predictions.length - 1]
  const priceChange = lastPrediction ? lastPrediction.price - currentPrice : 0
  const changePercent = lastPrediction ? (priceChange / currentPrice) * 100 : 0

  return (
    <div className="space-y-6">
      {/* Model Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {models.map((model) => (
          <Card
            key={model.id}
            className={`cursor-pointer transition-all duration-200 ${
              selectedModel === model.id ? "ring-2 ring-blue-500 shadow-lg" : "hover:shadow-md"
            }`}
            onClick={() => setSelectedModel(model.id)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-lg ${model.color} text-white`}>
                  <model.icon className="h-5 w-5" />
                </div>
                <div>
                  <CardTitle className="text-lg">{model.name}</CardTitle>
                  <div className="text-sm text-gray-600">{model.accuracy}% accuracy</div>
                </div>
              </div>
            </CardHeader>
          </Card>
        ))}
      </div>

      {/* Prediction Summary */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Price Prediction - {symbol}</CardTitle>
              <CardDescription>
                {selectedModelData?.name} forecast for the next {timeframe}
              </CardDescription>
            </div>
            <div className="flex space-x-2">
              {["7d", "30d", "90d"].map((tf) => (
                <Button
                  key={tf}
                  variant={timeframe === tf ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTimeframe(tf)}
                >
                  {tf}
                </Button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-sm text-gray-500">Current Price</div>
              <div className="text-2xl font-bold">
                {currency}
                {currentPrice.toFixed(2)}
              </div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-500">Predicted Price</div>
              <div className={`text-2xl font-bold ${priceChange >= 0 ? "text-green-600" : "text-red-600"}`}>
                {currency}
                {lastPrediction?.price.toFixed(2) || "N/A"}
              </div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-500">Expected Change</div>
              <div
                className={`text-2xl font-bold flex items-center justify-center ${
                  priceChange >= 0 ? "text-green-600" : "text-red-600"
                }`}
              >
                {priceChange >= 0 ? <TrendingUp className="h-5 w-5 mr-1" /> : <TrendingDown className="h-5 w-5 mr-1" />}
                {changePercent.toFixed(1)}%
              </div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-500">Confidence</div>
              <div className="text-2xl font-bold text-blue-600">{lastPrediction?.confidence.toFixed(0) || "N/A"}%</div>
            </div>
          </div>

          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={[
                  { date: "Today", price: currentPrice, type: "actual" },
                  ...predictions.map((p) => ({ ...p, type: "predicted" })),
                ]}
                margin={{ top: 10, right: 30, left: 20, bottom: 10 }}
              >
                <defs>
                  <linearGradient id="predictionGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis
                  domain={["auto", "auto"]}
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => `${currency}${value.toFixed(0)}`}
                />
                <Tooltip
                  formatter={(value: number, name: string) => [
                    `${currency}${value.toFixed(2)}`,
                    name === "price" ? "Price" : name,
                  ]}
                />
                <Area
                  type="monotone"
                  dataKey="price"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#predictionGradient)"
                  isAnimationActive={true}
                  animationDuration={1000}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Predictions */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Forecast</CardTitle>
          <CardDescription>Day-by-day price predictions with confidence intervals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {predictions.slice(0, 10).map((prediction, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="text-sm font-medium">{prediction.date}</div>
                  <div className="text-lg font-bold">
                    {currency}
                    {prediction.price.toFixed(2)}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline">{prediction.confidence.toFixed(0)}% confidence</Badge>
                  <Badge variant={prediction.price > currentPrice ? "default" : "destructive"}>
                    {prediction.price > currentPrice ? "+" : ""}
                    {(((prediction.price - currentPrice) / currentPrice) * 100).toFixed(1)}%
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
