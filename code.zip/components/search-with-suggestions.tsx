"use client"

import type React from "react"

import { useEffect, useMemo, useRef, useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Search, Building } from "lucide-react"
import { useRouter } from "next/navigation"
import stocksDb from "@/data/custom-indian-stocks.json"

type Suggestion = { symbol: string; name: string; exchange: string; isIndian: boolean }

export default function SearchWithSuggestions() {
  const [query, setQuery] = useState("")
  const [suggestions, setSuggestions] = useState<Suggestion[]>([])
  const [show, setShow] = useState(false)
  const [selectedIndex, setSelectedIndex] = useState(-1)
  const inputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  const indian: Suggestion[] = useMemo(() => {
    return (stocksDb as any[]).map((e) => ({
      symbol: String(e.symbol).toUpperCase(),
      name: e.name,
      exchange: String(e.exchange).toUpperCase(),
      isIndian: true,
    }))
  }, [])

  const us: Suggestion[] = [
    { symbol: "AAPL", name: "Apple Inc.", exchange: "NASDAQ", isIndian: false },
    { symbol: "MSFT", name: "Microsoft Corporation", exchange: "NASDAQ", isIndian: false },
    { symbol: "GOOGL", name: "Alphabet Inc. Class A", exchange: "NASDAQ", isIndian: false },
    { symbol: "TSLA", name: "Tesla, Inc.", exchange: "NASDAQ", isIndian: false },
    { symbol: "NVDA", name: "NVIDIA Corporation", exchange: "NASDAQ", isIndian: false },
    { symbol: "AMZN", name: "Amazon.com, Inc.", exchange: "NASDAQ", isIndian: false },
  ]

  const db = useMemo(() => [...indian, ...us], [indian])

  useEffect(() => {
    if (query.trim().length === 0) {
      setSuggestions([])
      setShow(false)
      return
    }
    const q = query.toLowerCase()
    const filtered = db
      .filter((s) => s.symbol.toLowerCase().includes(q) || s.name.toLowerCase().includes(q))
      .slice(0, 12)
    setSuggestions(filtered)
    setShow(true)
    setSelectedIndex(-1)
  }, [query, db])

  const select = (s: Suggestion) => {
    setQuery(s.symbol)
    setShow(false)
    // Pass exchange hint so backend treats NSE/BSE as Indian reliably
    const params = new URLSearchParams()
    params.set("exchange", s.exchange)
    router.push(`/stock/${s.symbol}?${params.toString()}`)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // If user presses enter without selecting a suggestion, default to NSE for Indian-ish symbols if present in db.
    const found = db.find((x) => x.symbol.toUpperCase() === query.toUpperCase())
    const exchange = found ? found.exchange : "NSE"
    const params = new URLSearchParams()
    params.set("exchange", exchange)
    router.push(`/stock/${query.toUpperCase()}?${params.toString()}`)
  }

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (!show) return
    if (e.key === "ArrowDown") {
      e.preventDefault()
      setSelectedIndex((p) => (p < suggestions.length - 1 ? p + 1 : p))
    } else if (e.key === "ArrowUp") {
      e.preventDefault()
      setSelectedIndex((p) => (p > 0 ? p - 1 : -1))
    } else if (e.key === "Enter") {
      e.preventDefault()
      if (selectedIndex >= 0) select(suggestions[selectedIndex])
      else if (query.trim()) {
        const found = suggestions[0]
        if (found) select(found)
        else handleSubmit(e as any)
      }
    } else if (e.key === "Escape") {
      setShow(false)
      setSelectedIndex(-1)
    }
  }

  return (
    <div className="relative">
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
          <Input
            ref={inputRef}
            type="text"
            placeholder="Search stocks (e.g., IRCTC, ABCAPITAL, ABFRL, RELIANCE, AAPL)…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onKeyDown}
            onFocus={() => query.length >= 1 && setShow(true)}
            onBlur={() => setTimeout(() => setShow(false), 150)}
            className="pl-12 pr-32 py-4 text-lg rounded-full border-2 border-gray-200 focus:border-emerald-500"
          />
          <Button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full px-8">
            Predict Now
          </Button>
        </div>
      </form>

      {show && suggestions.length > 0 && (
        <Card className="absolute top-full left-0 right-0 mt-2 z-50 shadow-lg border-2">
          <CardContent className="p-0">
            <div className="max-h-80 overflow-y-auto">
              {suggestions.map((s, i) => (
                <div
                  key={`${s.symbol}-${i}`}
                  onMouseDown={() => select(s)}
                  className={`flex items-center justify-between p-4 cursor-pointer transition-colors ${
                    i === selectedIndex ? "bg-emerald-50 border-l-4 border-emerald-500" : "hover:bg-gray-50"
                  } ${i !== suggestions.length - 1 ? "border-b" : ""}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                      <Building className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">{s.symbol}</div>
                      <div className="text-xs text-gray-600">{s.name}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-gray-500">{s.exchange}</div>
                    <div className="text-[10px] inline-block rounded-full px-2 py-0.5 bg-gray-100">
                      {s.isIndian ? "India" : "US"}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
