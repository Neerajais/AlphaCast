"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import type { StockData, PredictionData } from "@/types/stock"

interface PredictionChartProps {
  historicalData: StockData
  predictions: PredictionData
}

export default function PredictionChart({ historicalData, predictions }: PredictionChartProps) {
  // Get last 30 days of historical data
  const recentHistorical = historicalData.timeSeries.slice(0, 30).reverse()

  const chartData = [
    ...recentHistorical.map((item) => ({
      date: new Date(item.date).toLocaleDateString(),
      historical: item.close,
      predicted: null,
      confidence: null,
    })),
    ...predictions.predictions.map((item) => ({
      date: new Date(item.date).toLocaleDateString(),
      historical: null,
      predicted: item.price,
      confidence: item.confidence,
    })),
  ]

  return (
    <div className="space-y-4">
      <div className="w-full h-96">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" tick={{ fontSize: 12 }} interval="preserveStartEnd" />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip
              formatter={(value: number | null, name: string) => {
                if (value === null) return ["N/A", name]
                const currency = historicalData.isIndian ? "₹" : "$"
                return [
                  `${currency}${value.toFixed(2)}`,
                  name === "historical" ? "Historical Price" : name === "predicted" ? "Predicted Price" : "Confidence",
                ]
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="historical"
              stroke="#2563eb"
              strokeWidth={2}
              name="Historical Price"
              dot={false}
              connectNulls={false}
            />
            <Line
              type="monotone"
              dataKey="predicted"
              stroke="#dc2626"
              strokeWidth={2}
              strokeDasharray="5 5"
              name="Predicted Price"
              dot={false}
              connectNulls={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="font-semibold text-blue-900">Model Accuracy</h3>
          <p className="text-2xl font-bold text-blue-700">{predictions.accuracy}%</p>
        </div>
        <div className="bg-green-50 p-4 rounded-lg">
          <h3 className="font-semibold text-green-900">Trend Direction</h3>
          <p className="text-2xl font-bold text-green-700">{predictions.trend}</p>
        </div>
        <div className="bg-purple-50 p-4 rounded-lg">
          <h3 className="font-semibold text-purple-900">Avg Confidence</h3>
          <p className="text-2xl font-bold text-purple-700">
            {(
              predictions.predictions.reduce((sum, p) => sum + p.confidence, 0) / predictions.predictions.length
            ).toFixed(1)}
            %
          </p>
        </div>
      </div>
    </div>
  )
}
