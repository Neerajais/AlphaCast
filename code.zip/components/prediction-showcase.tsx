"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TrendingUp, TrendingDown, Brain, Target, Zap } from "lucide-react"
import { ResponsiveContainer, AreaChart, Area } from "recharts"

interface PredictionModel {
  name: string
  accuracy: number
  description: string
  icon: React.ReactNode
  color: string
}

interface StockPrediction {
  symbol: string
  currentPrice: number
  predictedPrice: number
  confidence: number
  timeframe: string
  trend: "up" | "down"
  change: number
  model: string
  data: Array<{ date: string; actual: number; predicted: number }>
}

export default function PredictionShowcase() {
  const [predictions, setPredictions] = useState<StockPrediction[]>([])
  const [selectedModel, setSelectedModel] = useState("lstm")

  const models: PredictionModel[] = [
    {
      name: "LSTM Neural Network",
      accuracy: 87.5,
      description: "Deep learning model for time series prediction",
      icon: <Brain className="h-5 w-5" />,
      color: "bg-blue-500",
    },
    {
      name: "Random Forest",
      accuracy: 82.3,
      description: "Ensemble learning for robust predictions",
      icon: <Target className="h-5 w-5" />,
      color: "bg-green-500",
    },
    {
      name: "Prophet",
      accuracy: 79.8,
      description: "Facebook's time series forecasting tool",
      icon: <Zap className="h-5 w-5" />,
      color: "bg-purple-500",
    },
  ]

  useEffect(() => {
    const generatePredictions = () => {
      const stocks = ["AAPL", "TSLA", "NVDA", "GOOGL", "MSFT", "AMZN"]

      return stocks.map((symbol) => {
        const currentPrice = 100 + Math.random() * 300
        const change = (Math.random() - 0.5) * 20
        const predictedPrice = currentPrice + change
        const trend = change > 0 ? "up" : "down"

        const data = Array.from({ length: 30 }, (_, i) => ({
          date: new Date(Date.now() + i * 24 * 60 * 60 * 1000).toLocaleDateString(),
          actual: currentPrice + (Math.random() - 0.5) * 10,
          predicted: predictedPrice + (Math.random() - 0.5) * 5,
        }))

        return {
          symbol,
          currentPrice,
          predictedPrice,
          confidence: 70 + Math.random() * 25,
          timeframe: "7 days",
          trend,
          change: Math.abs(change),
          model: selectedModel,
          data,
        }
      })
    }

    setPredictions(generatePredictions())
  }, [selectedModel])

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-2xl font-bold mb-2">AI Prediction Models</h3>
        <p className="text-gray-600">Advanced machine learning algorithms for accurate stock price forecasting</p>
      </div>

      {/* Model Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {models.map((model, index) => (
          <Card
            key={index}
            className={`cursor-pointer transition-all duration-200 ${
              selectedModel === model.name.toLowerCase().split(" ")[0]
                ? "ring-2 ring-blue-500 shadow-lg"
                : "hover:shadow-md"
            }`}
            onClick={() => setSelectedModel(model.name.toLowerCase().split(" ")[0])}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-lg ${model.color} text-white`}>{model.icon}</div>
                <div>
                  <CardTitle className="text-lg">{model.name}</CardTitle>
                  <div className="text-sm text-gray-600">{model.accuracy}% accuracy</div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">{model.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Predictions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {predictions.map((prediction) => (
          <Card key={prediction.symbol} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{prediction.symbol}</CardTitle>
                <Badge variant={prediction.trend === "up" ? "default" : "destructive"}>
                  {prediction.trend === "up" ? (
                    <TrendingUp className="h-3 w-3 mr-1" />
                  ) : (
                    <TrendingDown className="h-3 w-3 mr-1" />
                  )}
                  {prediction.trend === "up" ? "Bullish" : "Bearish"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-500">Current Price</div>
                    <div className="text-xl font-bold">${prediction.currentPrice.toFixed(2)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Predicted Price</div>
                    <div
                      className={`text-xl font-bold ${prediction.trend === "up" ? "text-green-600" : "text-red-600"}`}
                    >
                      ${prediction.predictedPrice.toFixed(2)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Confidence: {prediction.confidence.toFixed(1)}%</span>
                  <span className="text-gray-500">Timeframe: {prediction.timeframe}</span>
                </div>

                <div className="h-24">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={prediction.data.slice(0, 7)}>
                      <defs>
                        <linearGradient id={`gradient-${prediction.symbol}`} x1="0" y1="0" x2="0" y2="1">
                          <stop
                            offset="5%"
                            stopColor={prediction.trend === "up" ? "#10b981" : "#ef4444"}
                            stopOpacity={0.3}
                          />
                          <stop
                            offset="95%"
                            stopColor={prediction.trend === "up" ? "#10b981" : "#ef4444"}
                            stopOpacity={0}
                          />
                        </linearGradient>
                      </defs>
                      <Area
                        type="monotone"
                        dataKey="predicted"
                        stroke={prediction.trend === "up" ? "#10b981" : "#ef4444"}
                        fillOpacity={1}
                        fill={`url(#gradient-${prediction.symbol})`}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                <Button className="w-full" size="sm">
                  View Detailed Analysis
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Performance Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Model Performance Comparison</CardTitle>
          <CardDescription>Accuracy metrics across different prediction models</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {models.map((model, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${model.color} text-white`}>{model.icon}</div>
                  <div>
                    <div className="font-medium">{model.name}</div>
                    <div className="text-sm text-gray-600">{model.description}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">{model.accuracy}%</div>
                  <div className="text-sm text-gray-500">Accuracy</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
