"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Activity } from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface MarketIndex {
  name: string
  symbol: string
  value: number
  change: number
  changePercent: number
  data: Array<{ time: string; value: number }>
}

export default function MarketOverview() {
  const [marketIndices, setMarketIndices] = useState<MarketIndex[]>([])

  useEffect(() => {
    // Simulate market data
    const generateMarketData = () => {
      const indices = [
        { name: "S&P 500", symbol: "SPX", baseValue: 4200 },
        { name: "NASDAQ", symbol: "IXIC", baseValue: 13000 },
        { name: "Dow Jones", symbol: "DJI", baseValue: 34000 },
        { name: "Russell 2000", symbol: "RUT", baseValue: 1800 },
      ]

      return indices.map((index) => {
        const change = (Math.random() - 0.5) * 100
        const changePercent = (change / index.baseValue) * 100
        const data = Array.from({ length: 24 }, (_, i) => ({
          time: `${i}:00`,
          value: index.baseValue + (Math.random() - 0.5) * 200,
        }))

        return {
          ...index,
          value: index.baseValue + change,
          change,
          changePercent,
          data,
        }
      })
    }

    setMarketIndices(generateMarketData())
  }, [])

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {marketIndices.map((index) => (
          <Card key={index.symbol} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">{index.name}</CardTitle>
                <Badge variant={index.change >= 0 ? "default" : "destructive"}>{index.symbol}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{index.value.toFixed(2)}</div>
              <div className={`flex items-center text-sm ${index.change >= 0 ? "text-green-600" : "text-red-600"}`}>
                {index.change >= 0 ? (
                  <TrendingUp className="h-4 w-4 mr-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 mr-1" />
                )}
                {index.change >= 0 ? "+" : ""}
                {index.change.toFixed(2)} ({index.changePercent.toFixed(2)}%)
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Market Performance Today</CardTitle>
          <CardDescription>Real-time market indices performance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={marketIndices[0]?.data || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#2563eb" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
              Top Gainers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {["NVDA", "TSLA", "AMZN"].map((symbol, i) => (
                <div key={symbol} className="flex justify-between items-center">
                  <span className="font-medium">{symbol}</span>
                  <span className="text-green-600">+{(5 + i * 2).toFixed(2)}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingDown className="h-5 w-5 mr-2 text-red-600" />
              Top Losers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {["META", "NFLX", "GOOGL"].map((symbol, i) => (
                <div key={symbol} className="flex justify-between items-center">
                  <span className="font-medium">{symbol}</span>
                  <span className="text-red-600">-{(2 + i * 1.5).toFixed(2)}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="h-5 w-5 mr-2 text-blue-600" />
              Most Active
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {["AAPL", "MSFT", "SPY"].map((symbol, i) => (
                <div key={symbol} className="flex justify-between items-center">
                  <span className="font-medium">{symbol}</span>
                  <span className="text-gray-600">{(100 + i * 50).toFixed(0)}M</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
