"use client"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import type { StockDataPoint } from "@/types/stock"
import { getIndianStockPriceRange } from "@/utils/stock-utils"

interface StockChartDetailedProps {
  symbol: string
  currency?: string
  isIndian?: boolean
  // If provided, prefer real series over synthetic generation
  timeSeries?: StockDataPoint[]
}

export default function StockChartDetailed({
  symbol,
  currency = "$",
  isIndian = false,
  timeSeries,
}: StockChartDetailedProps) {
  const [timeframe, setTimeframe] = useState("1M")
  const [chartData, setChartData] = useState<any[]>([])

  const computedFromSeries = useMemo(() => {
    if (!timeSeries || timeSeries.length === 0) return []

    // timeSeries is newest-first in our API; convert to oldest-first for slicing windows
    const sorted = [...timeSeries].sort((a, b) => (a.date < b.date ? -1 : 1))
    const pickCount =
      timeframe === "1D" ? 24 : timeframe === "1W" ? 7 : timeframe === "1M" ? 30 : timeframe === "3M" ? 90 : 365
    const take = sorted.slice(Math.max(0, sorted.length - pickCount))

    return take.map((d) => ({
      date: new Date(d.date).toLocaleDateString(),
      price: d.close,
      volume: d.volume,
    }))
  }, [timeSeries, timeframe])

  useEffect(() => {
    if (computedFromSeries.length > 0) {
      setChartData(computedFromSeries)
      return
    }

    // Synthetic fallback if no series provided
    const periods =
      timeframe === "1D" ? 24 : timeframe === "1W" ? 7 : timeframe === "1M" ? 30 : timeframe === "3M" ? 90 : 365

    let basePrice = 150
    if (isIndian) {
      const range = getIndianStockPriceRange(symbol)
      basePrice = range[0] + Math.random() * (range[1] - range[0])
    } else {
      basePrice = 50 + Math.random() * 400
    }

    let currentPrice = basePrice
    const trend = (Math.random() - 0.5) * 0.01
    const volatilityFactor = isIndian ? 0.015 : 0.02

    const synthetic = Array.from({ length: periods }, (_, i) => {
      const date = new Date()
      date.setDate(date.getDate() - (periods - i))
      const dailyVolatility = (Math.random() - 0.5) * volatilityFactor * currentPrice
      const dailyTrend = trend * currentPrice
      currentPrice = Math.max(currentPrice + dailyTrend + dailyVolatility, basePrice * 0.5)
      return {
        date: timeframe === "1D" ? date.toLocaleTimeString() : date.toLocaleDateString(),
        price: currentPrice,
        volume: Math.floor(Math.random() * (isIndian ? 50000000 : 10000000)),
      }
    })

    setChartData(synthetic)
  }, [timeframe, symbol, isIndian, computedFromSeries])

  const timeframes = ["1D", "1W", "1M", "3M", "1Y"]

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>{symbol} Price Chart</CardTitle>
            <CardDescription>Interactive price chart with technical analysis</CardDescription>
          </div>
          <div className="flex space-x-1">
            {timeframes.map((tf) => (
              <Button
                key={tf}
                variant={timeframe === tf ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeframe(tf)}
              >
                {tf}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-96 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis
                domain={["auto", "auto"]}
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `${currency}${Number(value).toFixed(0)}`}
              />
              <Tooltip
                formatter={(value: number) => [`${currency}${Number(value).toFixed(2)}`, "Price"]}
                labelFormatter={(label) => `Time: ${label}`}
              />
              <Line
                type="monotone"
                dataKey="price"
                stroke="#2563eb"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
                isAnimationActive={true}
                animationDuration={800}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
