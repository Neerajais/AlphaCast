"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, DollarSign, BarChart } from "lucide-react"

interface StockMetricsProps {
  stockData: any
}

export default function StockMetrics({ stockData }: StockMetricsProps) {
  const latest = stockData.timeSeries[0]
  const previous = stockData.timeSeries[1]
  const change = latest.close - previous.close
  const changePercent = (change / previous.close) * 100

  // Use currency from stockData, with fallback logic
  const currency = stockData.currency || (stockData.isIndian ? "₹" : "$")

  const metrics = [
    {
      title: "Current Price",
      value: `${currency}${latest.close.toFixed(2)}`,
      icon: DollarSign,
      color: "text-blue-600",
    },
    {
      title: "Daily Change",
      value: `${change >= 0 ? "+" : ""}${currency}${change.toFixed(2)}`,
      icon: change >= 0 ? TrendingUp : TrendingDown,
      color: change >= 0 ? "text-green-600" : "text-red-600",
    },
    {
      title: "Change %",
      value: `${change >= 0 ? "+" : ""}${changePercent.toFixed(2)}%`,
      icon: change >= 0 ? TrendingUp : TrendingDown,
      color: change >= 0 ? "text-green-600" : "text-red-600",
    },
    {
      title: "Volume",
      value: `${(latest.volume / 1000000).toFixed(1)}M`,
      icon: BarChart,
      color: "text-purple-600",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((metric, index) => (
        <Card key={index}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{metric.title}</CardTitle>
            <metric.icon className={`h-4 w-4 ${metric.color}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${metric.color}`}>{metric.value}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
