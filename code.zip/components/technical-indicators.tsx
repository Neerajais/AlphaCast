"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

interface TechnicalIndicator {
  name: string
  value: number
  signal: "buy" | "sell" | "neutral"
  description: string
}

interface TechnicalIndicatorsProps {
  symbol: string
  currency?: string
  isIndian?: boolean
}

export default function TechnicalIndicators({ symbol, currency = "$", isIndian = false }: TechnicalIndicatorsProps) {
  const [indicators, setIndicators] = useState<TechnicalIndicator[]>([])

  useEffect(() => {
    // Generate realistic technical indicators based on the stock
    const generateIndicators = (): TechnicalIndicator[] => {
      // Use the symbol to seed the random number generator for consistency
      const symbolSeed = symbol.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0)
      const seedRandom = (min: number, max: number) => {
        const x = Math.sin(symbolSeed + Date.now()) * 10000
        return min + (x - Math.floor(x)) * (max - min)
      }

      // Generate RSI (30-70 is neutral, <30 is oversold/buy, >70 is overbought/sell)
      const rsiValue = 30 + seedRandom(0, 40)
      const rsiSignal = rsiValue < 30 ? "buy" : rsiValue > 70 ? "sell" : "neutral"

      // Generate MACD (-2 to 2 range, positive is bullish/buy, negative is bearish/sell)
      const macdValue = (seedRandom(0, 1) - 0.5) * 4
      const macdSignal = macdValue > 0.5 ? "buy" : macdValue < -0.5 ? "sell" : "neutral"

      // Generate Stochastic (0-100 range, <20 is oversold/buy, >80 is overbought/sell)
      const stochasticValue = seedRandom(0, 100)
      const stochasticSignal = stochasticValue < 20 ? "buy" : stochasticValue > 80 ? "sell" : "neutral"

      // Generate Williams %R (-100 to 0 range, <-80 is oversold/buy, >-20 is overbought/sell)
      const williamsValue = -seedRandom(0, 100)
      const williamsSignal = williamsValue < -80 ? "buy" : williamsValue > -20 ? "sell" : "neutral"

      // Generate CCI (-200 to 200 range, <-100 is oversold/buy, >100 is overbought/sell)
      const cciValue = (seedRandom(0, 1) - 0.5) * 400
      const cciSignal = cciValue < -100 ? "buy" : cciValue > 100 ? "sell" : "neutral"

      return [
        {
          name: "RSI (14)",
          value: rsiValue,
          signal: rsiSignal,
          description: "Relative Strength Index",
        },
        {
          name: "MACD",
          value: macdValue,
          signal: macdSignal,
          description: "Moving Average Convergence Divergence",
        },
        {
          name: "Stochastic",
          value: stochasticValue,
          signal: stochasticSignal,
          description: "Stochastic Oscillator",
        },
        {
          name: "Williams %R",
          value: williamsValue,
          signal: williamsSignal,
          description: "Williams Percent Range",
        },
        {
          name: "CCI",
          value: cciValue,
          signal: cciSignal,
          description: "Commodity Channel Index",
        },
      ]
    }

    setIndicators(generateIndicators())
  }, [symbol])

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case "buy":
        return "text-green-600 bg-green-50"
      case "sell":
        return "text-red-600 bg-red-50"
      default:
        return "text-gray-600 bg-gray-50"
    }
  }

  const getSignalIcon = (signal: string) => {
    switch (signal) {
      case "buy":
        return <TrendingUp className="h-4 w-4" />
      case "sell":
        return <TrendingDown className="h-4 w-4" />
      default:
        return <Minus className="h-4 w-4" />
    }
  }

  const overallSignal = () => {
    const buyCount = indicators.filter((i) => i.signal === "buy").length
    const sellCount = indicators.filter((i) => i.signal === "sell").length

    if (buyCount > sellCount) return "buy"
    if (sellCount > buyCount) return "sell"
    return "neutral"
  }

  const buyPercentage = (indicators.filter((i) => i.signal === "buy").length / indicators.length) * 100

  return (
    <Card>
      <CardHeader>
        <CardTitle>Technical Indicators</CardTitle>
        <CardDescription>Real-time technical analysis signals</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Overall Signal */}
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Overall Signal</span>
              <Badge className={getSignalColor(overallSignal())}>
                {getSignalIcon(overallSignal())}
                <span className="ml-1 capitalize">{overallSignal()}</span>
              </Badge>
            </div>
            <Progress value={buyPercentage} className="h-2" />
          </div>

          {/* Individual Indicators */}
          {indicators.map((indicator, index) => (
            <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <div className="font-medium">{indicator.name}</div>
                <div className="text-sm text-gray-500">{indicator.description}</div>
                <div className="text-sm font-mono">{indicator.value.toFixed(2)}</div>
              </div>
              <Badge className={getSignalColor(indicator.signal)}>
                {getSignalIcon(indicator.signal)}
                <span className="ml-1 capitalize">{indicator.signal}</span>
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
