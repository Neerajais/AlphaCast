"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts"
import { TrendingUp, TrendingDown, DollarSign, Eye, Plus, Trash2 } from "lucide-react"
import Link from "next/link"

interface PortfolioStock {
  symbol: string
  name: string
  shares: number
  avgPrice: number
  currentPrice: number
  value: number
  change: number
  changePercent: number
}

interface WatchlistStock {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
}

export default function DashboardPage() {
  const [portfolio, setPortfolio] = useState<PortfolioStock[]>([])
  const [watchlist, setWatchlist] = useState<WatchlistStock[]>([])
  const [portfolioValue, setPortfolioValue] = useState(0)
  const [totalGainLoss, setTotalGainLoss] = useState(0)

  useEffect(() => {
    // Mock portfolio data
    const mockPortfolio: PortfolioStock[] = [
      {
        symbol: "AAPL",
        name: "Apple Inc.",
        shares: 50,
        avgPrice: 150.0,
        currentPrice: 175.43,
        value: 8771.5,
        change: 1271.5,
        changePercent: 16.95,
      },
      {
        symbol: "MSFT",
        name: "Microsoft Corporation",
        shares: 25,
        avgPrice: 300.0,
        currentPrice: 338.11,
        value: 8452.75,
        change: 952.75,
        changePercent: 12.7,
      },
      {
        symbol: "GOOGL",
        name: "Alphabet Inc.",
        shares: 30,
        avgPrice: 120.0,
        currentPrice: 125.37,
        value: 3761.1,
        change: 161.1,
        changePercent: 4.48,
      },
      {
        symbol: "TSLA",
        name: "Tesla, Inc.",
        shares: 15,
        avgPrice: 200.0,
        currentPrice: 248.5,
        value: 3727.5,
        change: 727.5,
        changePercent: 24.25,
      },
    ]

    const mockWatchlist: WatchlistStock[] = [
      { symbol: "NVDA", name: "NVIDIA Corporation", price: 421.13, change: 12.45, changePercent: 3.05 },
      { symbol: "AMZN", name: "Amazon.com, Inc.", price: 127.74, change: 1.87, changePercent: 1.49 },
      { symbol: "META", name: "Meta Platforms, Inc.", price: 298.58, change: -2.34, changePercent: -0.78 },
      { symbol: "NFLX", name: "Netflix, Inc.", price: 445.92, change: -5.67, changePercent: -1.26 },
    ]

    setPortfolio(mockPortfolio)
    setWatchlist(mockWatchlist)

    const totalValue = mockPortfolio.reduce((sum, stock) => sum + stock.value, 0)
    const totalCost = mockPortfolio.reduce((sum, stock) => sum + stock.shares * stock.avgPrice, 0)

    setPortfolioValue(totalValue)
    setTotalGainLoss(totalValue - totalCost)
  }, [])

  const portfolioData = portfolio.map((stock) => ({
    name: stock.symbol,
    value: stock.value,
    percentage: ((stock.value / portfolioValue) * 100).toFixed(1),
  }))

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Investment Dashboard</h1>
            <nav className="flex items-center space-x-6">
              <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium">
                Home
              </Link>
              <Link href="/dashboard" className="text-blue-600 font-medium">
                Dashboard
              </Link>
              <Link href="/predictions" className="text-gray-700 hover:text-blue-600 font-medium">
                Predictions
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Portfolio Summary */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Portfolio Value</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${portfolioValue.toLocaleString()}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Gain/Loss</CardTitle>
              {totalGainLoss >= 0 ? (
                <TrendingUp className="h-4 w-4 text-green-600" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-600" />
              )}
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${totalGainLoss >= 0 ? "text-green-600" : "text-red-600"}`}>
                {totalGainLoss >= 0 ? "+" : ""}${totalGainLoss.toLocaleString()}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Holdings</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{portfolio.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Watchlist</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{watchlist.length}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="portfolio" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
            <TabsTrigger value="watchlist">Watchlist</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="portfolio" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Portfolio Holdings */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Portfolio Holdings</CardTitle>
                    <CardDescription>Your current stock positions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {portfolio.map((stock) => (
                        <div
                          key={stock.symbol}
                          className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                        >
                          <div className="flex items-center space-x-4">
                            <div>
                              <Link href={`/stock/${stock.symbol}`} className="font-medium hover:text-blue-600">
                                {stock.symbol}
                              </Link>
                              <div className="text-sm text-gray-600">{stock.name}</div>
                              <div className="text-xs text-gray-500">
                                {stock.shares} shares @ ${stock.avgPrice.toFixed(2)}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-medium">${stock.value.toLocaleString()}</div>
                            <div className={`text-sm ${stock.change >= 0 ? "text-green-600" : "text-red-600"}`}>
                              {stock.change >= 0 ? "+" : ""}${stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}
                              %)
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Portfolio Allocation */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Asset Allocation</CardTitle>
                    <CardDescription>Portfolio distribution by holdings</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={portfolioData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {portfolioData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: number) => [`$${value.toLocaleString()}`, "Value"]} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="space-y-2 mt-4">
                      {portfolioData.map((item, index) => (
                        <div key={item.name} className="flex items-center justify-between text-sm">
                          <div className="flex items-center">
                            <div
                              className="w-3 h-3 rounded-full mr-2"
                              style={{ backgroundColor: COLORS[index % COLORS.length] }}
                            />
                            {item.name}
                          </div>
                          <span>{item.percentage}%</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="watchlist" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Watchlist</CardTitle>
                  <CardDescription>Stocks you're monitoring</CardDescription>
                </div>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Stock
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {watchlist.map((stock) => (
                    <div
                      key={stock.symbol}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                    >
                      <div>
                        <Link href={`/stock/${stock.symbol}`} className="font-medium hover:text-blue-600">
                          {stock.symbol}
                        </Link>
                        <div className="text-sm text-gray-600">{stock.name}</div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <div className="font-medium">${stock.price.toFixed(2)}</div>
                          <div className={`text-sm ${stock.change >= 0 ? "text-green-600" : "text-red-600"}`}>
                            {stock.change >= 0 ? "+" : ""}
                            {stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Portfolio Performance</CardTitle>
                <CardDescription>Historical performance over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={Array.from({ length: 30 }, (_, i) => ({
                        date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toLocaleDateString(),
                        value: portfolioValue + (Math.random() - 0.5) * 2000,
                      }))}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip formatter={(value: number) => [`$${value.toLocaleString()}`, "Portfolio Value"]} />
                      <Line type="monotone" dataKey="value" stroke="#2563eb" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
