"use client"

import type React from "react"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <style
          dangerouslySetInnerHTML={{
            __html: `
            /* Additional watermark removal */
            [data-v0-watermark] { display: none !important; }
            .v0-watermark { display: none !important; }
            div[style*="Built with"] { display: none !important; }
            div[style*="position: fixed"][style*="bottom"][style*="right"] { display: none !important; }
          `,
          }}
        />
      </head>
      <body className={inter.className}>
        {children}
        <style jsx global>{`
          /* Runtime watermark removal */
          [data-v0-watermark],
          .v0-watermark,
          div[style*="Built with"] {
            display: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
          }
        `}</style>
      </body>
    </html>
  )
}
