import StockDetailClient from "@/components/stock-detail-client"
import { notFound } from "next/navigation"

export default async function StockPage({
  params,
  searchParams,
}: {
  params: { symbol: string }
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const symbol = params.symbol?.toUpperCase()
  if (!symbol) return notFound()

  const exchange = typeof searchParams.exchange === "string" ? (searchParams.exchange as string) : undefined

  // Fetch initial data on the server and pass it down to the client component.
  const base = process.env.NEXT_PUBLIC_BASE_URL || ""
  let initial: any = null

  try {
    const res = await fetch(`${base}/api/stock-data`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol, exchange }),
      cache: "no-store",
    })
    initial = res.ok ? await res.json() : null
  } catch {
    initial = null
  }

  return <StockDetailClient symbol={symbol} exchange={exchange} initial={initial} />
}
