export interface StockDataPoint {
  date: string
  open: number
  high: number
  low: number
  close: number
  volume: number
  ma20?: number
  ma50?: number
  // Future indicators can be added here (e.g., rsi, macd...)
}

export interface StockData {
  symbol: string
  timeSeries: StockDataPoint[]
  lastRefreshed: string
  // Added for currency-correct rendering across the app
  currency?: string // "$" | "₹"
  isIndian?: boolean
  exchange?: string // e.g. "NSE", "NASDAQ"
}

export interface PredictionPoint {
  date: string
  price: number
  confidence: number
}

export interface PredictionData {
  predictions: PredictionPoint[]
  accuracy: number
  trend: "Bullish" | "Bearish" | "Neutral"
  model: string
}
